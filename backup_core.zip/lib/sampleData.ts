import { Project } from './types';
import { uid } from './projectUtils';

export const seedProjects: Project[] = [
  {
    id: uid(),
    pjtNo: "PJT-24037",
    name: "Busan Dryer Retrofit",
    country: "Korea",
    city: "Busan",
    status: "진행 중",
    pm: "K. Lee",
    salesManagers: ["J. Kim", "Y. Park"],
    designManagers: ["S. Park", "B. Lee"],
    controlManagers: ["M. Choi"],
    productionManagers: ["H. Jung", "K. Yoon"],
    budget: 180000000,
    actualCost: 125000000,
    progress: 70,
    startDate: "2024-01-01",
    endDate: "2024-06-30",
    lat: 35.1796,
    lng: 129.0756,
    address: "부산광역시",
    note: "코안다 노즐 테스트 라인 포함",
    equipmentHistory: [
      {
        id: uid(),
        date: "2024-01-15",
        part: "기구",
        content: "코안다 노즐 마모로 인한 성능 저하",
        action: "새로운 노즐로 교체",
        manager: "K. Yoon"
      },
      {
        id: uid(),
        date: "2024-02-20",
        part: "제어",
        content: "테스트 라인 속도 조정 필요",
        action: "모터 속도 조정 및 테스트",
        manager: "H. Jung"
      }
    ],
  },
  {
    id: uid(),
    pjtNo: "PJT-25012",
    name: "Nagoya Web Handling Study",
    country: "Japan",
    city: "Nagoya",
    status: "계획",
    pm: "M. Ito",
    salesManagers: ["T. Tanaka"],
    designManagers: ["Y. Suzuki", "H. Nakamura"],
    controlManagers: ["K. Watanabe"],
    productionManagers: ["A. Yamamoto"],
    budget: 95000000,
    actualCost: 0,
    progress: 0,
    startDate: "2024-07-01",
    endDate: "2024-12-31",
    lat: 35.1815,
    lng: 136.9066,
    address: "Aichi, Nagoya",
    note: "양면 코팅 라인 안정화",
    equipmentHistory: [
      {
        id: uid(),
        date: "2024-03-10",
        part: "기구",
        content: "양면 코팅 시스템 코팅 두께 불균일 문제",
        action: "노즐 압력 조정 및 캘리브레이션",
        manager: "Y. Suzuki"
      }
    ],
  },
  {
    id: uid(),
    pjtNo: "PJT-24105",
    name: "Phoenix Quotation Roll Upgrade",
    country: "USA",
    city: "Phoenix",
    status: "진행 중(관리필요)",
    pm: "S. Park",
    salesManagers: ["R. Johnson", "M. Wilson"],
    designManagers: ["L. Smith"],
    controlManagers: ["D. Brown", "E. Taylor"],
    productionManagers: ["C. Davis"],
    budget: 120000000,
    actualCost: 95000000,
    progress: 80,
    startDate: "2024-03-01",
    endDate: "2024-08-31",
    lat: 33.4484,
    lng: -112.0740,
    address: "Phoenix, AZ",
    note: "견적 재협상 대기 - 관리 필요",
    equipmentHistory: [
      {
        id: uid(),
        date: "2024-04-05",
        part: "제어",
        content: "견적 시스템 원가 상승으로 인한 견적 재검토 필요",
        action: "공급업체와 재협상 진행 중",
        manager: "R. Johnson"
      }
    ],
  },
];
