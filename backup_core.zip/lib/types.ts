// 프로젝트 관련 타입 정의
export interface Project {
  id: string;
  pjtNo: string;
  name: string;
  status: string;
  pm: string;
  salesManagers?: string[];
  designManagers?: string[];
  controlManagers?: string[];
  productionManagers?: string[];
  budget: number;
  actualCost: number;
  progress: number;
  startDate: string;
  endDate: string;
  note?: string;
  lat: number;
  lng: number;
  country?: string;
  city?: string;
  address?: string;
  equipmentHistory?: EquipmentHistory[];
  scheduleItems?: ScheduleItem[];
  people?: Person[];
}

export interface EquipmentHistory {
  id: string;
  date: string;
  part: string;
  content: string;
  action: string;
  manager: string;
}

export interface ScheduleItem {
  id: string;
  name: string;
  startDate: string;
  endDate: string;
  progress: number;
}

export interface Person {
  id: string;
  name: string;
  affiliation: string;
  department: string;
}

export interface ManagerStatus {
  [personId: string]: Record<string, string>;
}

export interface Dependency {
  from: string;
  to: string;
}

export interface Threshold {
  itemId: string;
  type: 'progress' | 'date';
  value: number;
  message: string;
}

export type ProjectStatus = '계획' | '진행 중' | '진행 중(관리필요)' | '일시 중단' | '완료';
export type ActiveTab = 'overview' | 'projects' | 'schedule' | 'analytics';
