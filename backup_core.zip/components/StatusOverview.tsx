'use client';

import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Filter } from 'lucide-react';

interface Project {
  id: string;
  status: string;
}

interface StatusOverviewProps {
  projects: Project[];
}

const STATUS_CONFIG = [
  { key: "계획", color: "bg-blue-100 text-blue-700", bgColor: "bg-blue-100" },
  { key: "진행 중", color: "bg-green-100 text-green-700", bgColor: "bg-green-100" },
  { key: "진행 중(관리필요)", color: "bg-red-100 text-red-700", bgColor: "bg-red-100" },
  { key: "일시 중단", color: "bg-amber-100 text-amber-700", bgColor: "bg-amber-100" },
  { key: "완료", color: "bg-zinc-100 text-zinc-700", bgColor: "bg-zinc-100" }
] as const;

function StatusBadge({ status }: { status: string }) {
  const statusLabels: Record<string, string> = {
    "Planning": "계획",
    "Active": "진행 중",
    "Active_Management": "진행 중\n(관리필요)",
    "On Hold": "일시 중단",
    "Closed": "완료",
    "계획": "계획",
    "진행 중": "진행 중",
    "진행 중(관리필요)": "진행 중\n(관리필요)",
    "일시 중단": "일시 중단",
    "완료": "완료",
  };
  
  const displayStatus = statusLabels[status] || status;
  const cls = STATUS_CONFIG.find(s => s.key === displayStatus)?.color || "bg-zinc-100 text-zinc-700";
  
  if (displayStatus.includes('\n')) {
    const [line1, line2] = displayStatus.split('\n');
    return (
      <Badge className={`rounded-full px-3 py-1 text-xs leading-tight ${cls}`}>
        <div className="text-center">
          <div>{line1}</div>
          <div className="text-[10px]">{line2}</div>
        </div>
      </Badge>
    );
  }
  
  return <Badge className={`rounded-full px-3 py-1 text-xs ${cls}`}>{displayStatus}</Badge>;
}

export default function StatusOverview({ projects }: StatusOverviewProps) {
  return (
    <Card className="shadow-sm">
      <CardContent className="p-0">
        <div className="p-3 border-b flex items-center gap-2">
          <Filter className="h-4 w-4 text-green-600" />
          <h2 className="font-semibold text-base">상태별 현황</h2>
          <Badge variant="outline" className="ml-auto text-xs">
            {projects.length}개 총 프로젝트
          </Badge>
        </div>
        <div className="p-3">
          <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
            {STATUS_CONFIG.map(({ key, color, bgColor }) => {
              const count = projects.filter((p) => p.status === key).length;
              return (
                <div key={key} className="text-center p-3 rounded-lg hover:bg-gray-50 transition-colors">
                  <div className="mb-2">
                    <StatusBadge status={key} />
                  </div>
                  <div className="text-2xl font-bold text-gray-900">{count}개</div>
                </div>
              );
            })}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

