"use client";
import React, { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RefreshCw, Info, Copy, MapPin } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

interface LocationManagerProps {
  lat: number | undefined;
  lng: number | undefined;
  onLocationChange: (lat: number, lng: number) => void;
}

export default function LocationManager({ lat, lng, onLocationChange }: LocationManagerProps) {
  const [mounted, setMounted] = useState(false);
  const [addressSearch, setAddressSearch] = useState("");
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<any>(null);
  const markerRef = useRef<any>(null);

  // 컴포넌트 마운트 확인
  useEffect(() => {
    setMounted(true);
  }, []);

  // Leaflet 지도 초기화
  useEffect(() => {
    if (!mounted || !mapRef.current) {
      console.log('LocationManager: 마운트 상태 또는 mapRef 확인 실패', { mounted, mapRef: !!mapRef.current });
      return;
    }

    console.log('LocationManager: 지도 초기화 시작', { lat, lng });

    const initMap = async () => {
      try {
        // Leaflet 동적 import
        const L = await import('leaflet');
        console.log('LocationManager: Leaflet 모듈 로드 완료');

        // 기존 지도 제거
        if (mapInstanceRef.current) {
          console.log('LocationManager: 기존 지도 제거');
          mapInstanceRef.current.remove();
          mapInstanceRef.current = null;
        }

        // 새 지도 생성 - 줌 컨트롤과 상호작용 옵션 개선
        const map = L.map(mapRef.current!, {
          center: [lat || 37.5665, lng || 126.9780],
          zoom: lat && lng ? 15 : 5,
          zoomControl: true,
          attributionControl: false,
          scrollWheelZoom: true,
          doubleClickZoom: true,
          boxZoom: true,
          keyboard: true,
          dragging: true,
          touchZoom: true
        });

        console.log('LocationManager: 지도 인스턴스 생성 완료', { center: map.getCenter(), zoom: map.getZoom() });

        // 타일 레이어 추가
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
          maxZoom: 18,
          minZoom: 3
        }).addTo(map);

        console.log('LocationManager: 타일 레이어 추가 완료');

        // 마커 아이콘 설정 (기본 아이콘 사용)
        const defaultIcon = L.divIcon({
          className: 'custom-marker',
          html: '<div style="background-color: #e74c3c; width: 20px; height: 20px; border-radius: 50%; border: 2px solid white; box-shadow: 0 2px 4px rgba(0,0,0,0.3); cursor: pointer;"></div>',
          iconSize: [20, 20],
          iconAnchor: [10, 10]
        });

        // 마커 추가 (좌표가 있는 경우)
        if (lat && lng) {
          console.log('LocationManager: 초기 마커 추가', { lat, lng });
          markerRef.current = L.marker([lat, lng], { icon: defaultIcon }).addTo(map);
          markerRef.current.bindPopup(`위도: ${lat.toFixed(6)}<br>경도: ${lng.toFixed(6)}`);
          
          // 마커 클릭 이벤트
          markerRef.current.on('click', () => {
            markerRef.current.openPopup();
          });
        }

        // 지도 클릭 이벤트 - 이벤트 중복 방지
        const handleMapClick = (e: any) => {
          console.log('LocationManager: 지도 클릭됨:', e.latlng);
          const { lat: clickedLat, lng: clickedLng } = e.latlng;
          
          // 기존 마커 제거 (올바른 메서드 사용)
          if (markerRef.current && map.hasLayer(markerRef.current)) {
            console.log('LocationManager: 기존 마커 제거');
            map.removeLayer(markerRef.current);
          }
          
          // 새 마커 추가
          markerRef.current = L.marker([clickedLat, clickedLng], { icon: defaultIcon }).addTo(map);
          markerRef.current.bindPopup(`위도: ${clickedLat.toFixed(6)}<br>경도: ${clickedLng.toFixed(6)}`);
          
          // 마커 클릭 이벤트
          markerRef.current.on('click', () => {
            markerRef.current.openPopup();
          });
          
          // 좌표 업데이트
          console.log('LocationManager: 좌표 업데이트:', clickedLat, clickedLng);
          onLocationChange(clickedLat, clickedLng);
        };

        // 이벤트 리스너 등록
        map.on('click', handleMapClick);

        // 줌 변경 이벤트 리스너
        map.on('zoomend', () => {
          const currentZoom = map.getZoom();
          console.log('LocationManager: 줌 변경됨:', currentZoom);
        });

        // 이동 완료 이벤트 리스너
        map.on('moveend', () => {
          const center = map.getCenter();
          console.log('LocationManager: 지도 이동 완료:', center);
        });

        mapInstanceRef.current = map;
        console.log('LocationManager: 지도 초기화 완료');
      } catch (error) {
        console.error('LocationManager: 지도 초기화 오류:', error);
      }
    };

    initMap();

    // 클린업
    return () => {
      console.log('LocationManager: 컴포넌트 언마운트, 정리 작업 시작');
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
      }
      markerRef.current = null;
      console.log('LocationManager: 정리 작업 완료');
    };
  }, [mounted, lat, lng, onLocationChange]);

  // 구글 맵에서 검색
  const openGoogleMaps = () => {
    if (!addressSearch.trim()) {
      alert('검색할 주소를 입력해주세요.');
      return;
    }
    
    // 구글 맵 검색 URL 생성
    const searchQuery = encodeURIComponent(addressSearch);
    const googleMapsUrl = `https://www.google.com/maps/search/${searchQuery}`;
    
    // 새 탭에서 구글 맵 열기
    window.open(googleMapsUrl, '_blank');
  };

  // 지도 새로고침
  const refreshMap = () => {
    if (mapInstanceRef.current) {
      const center = [lat || 37.5665, lng || 126.9780];
      const zoom = lat && lng ? 15 : 5;
      mapInstanceRef.current.setView(center, zoom);
      
      // 마커도 함께 업데이트
      if (lat && lng) {
        // 기존 마커 제거
        if (markerRef.current && mapInstanceRef.current.hasLayer(markerRef.current)) {
          mapInstanceRef.current.removeLayer(markerRef.current);
        }
        
        // 새 마커 추가
        (async () => {
          const L = await import('leaflet');
          const defaultIcon = L.divIcon({
            className: 'custom-marker',
            html: '<div style="background-color: #e74c3c; width: 20px; height: 20px; border-radius: 50%; border: 2px solid white; box-shadow: 0 2px 4px rgba(0,0,0,0.3); cursor: pointer;"></div>',
            iconSize: [20, 20],
            iconAnchor: [10, 10]
          });
          markerRef.current = L.marker([lat, lng], { icon: defaultIcon }).addTo(mapInstanceRef.current);
          markerRef.current.bindPopup(`위도: ${lat.toFixed(6)}<br>경도: ${lng.toFixed(6)}`);
        })();
      }
    }
  };

  return (
    <div className="space-y-4">
      {/* 설정된 좌표 위치 표시 지도 */}
      <div>
        <Label className="mb-2 block">설정된 좌표 위치</Label>
        <div className="location-manager-map border rounded-lg overflow-hidden relative" style={{ background: '#f6f7fb' }}>
          {mounted && (
            <div ref={mapRef} className="w-full h-full" />
          )}
          
          {/* 지도 새로고침 버튼 */}
          <div className="absolute top-2 right-2 z-30">
            <Button 
              size="sm" 
              variant="secondary"
              onClick={refreshMap}
              className="bg-white/90 hover:bg-white text-gray-700"
              title="지도 새로고침"
            >
              <RefreshCw className="h-4 w-4" />
            </Button>
          </div>

          {/* 지도 사용법 안내 */}
          <div className="absolute top-2 left-2 bg-white/90 px-2 py-1 rounded text-xs text-gray-600 z-30">
            💡 지도를 클릭하여 위치를 설정하세요
          </div>
        </div>
        <p className="text-xs text-zinc-500 mt-1">
          지도를 클릭하여 좌표를 설정하거나, 아래에서 주소를 검색하여 좌표를 찾을 수 있습니다.
        </p>
      </div>
      
      <div className="space-y-4">
        {/* 구글 맵 검색창 연결 */}
        <div>
          <Label>구글 맵에서 주소 검색</Label>
          <div className="flex gap-2">
            <Input 
              placeholder="주소를 입력하세요 (예: 서울시 강남구)" 
              value={addressSearch}
              onChange={(e) => setAddressSearch(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && openGoogleMaps()}
            />
            <Button 
              onClick={openGoogleMaps} 
              size="sm"
              variant="outline"
              className="whitespace-nowrap"
            >
              🌍 구글맵
            </Button>
            <Dialog>
              <DialogTrigger asChild>
                <Button size="sm" variant="ghost" className="px-2">
                  <Info className="h-4 w-4" />
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-md">
                <DialogHeader>
                  <DialogTitle className="flex items-center gap-2">
                    <MapPin className="h-5 w-5 text-blue-600" />
                    구글맵에서 좌표 복사하는 방법
                  </DialogTitle>
                  <DialogDescription>
                    구글맵에서 원하는 위치의 좌표를 복사해서 입력란에 붙여넣으세요
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex items-start gap-3 p-3 bg-blue-50 rounded-lg">
                      <div className="text-blue-600 text-lg">1️⃣</div>
                      <div className="text-sm">
                        <p className="font-medium text-blue-900">구글맵에서 주소 검색</p>
                        <p className="text-blue-700 mt-1">위의 구글맵 버튼을 클릭하여 원하는 주소를 검색하세요</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3 p-3 bg-green-50 rounded-lg">
                      <div className="text-green-600 text-lg">2️⃣</div>
                      <div className="text-sm">
                        <p className="font-medium text-green-900">위치 우클릭</p>
                        <p className="text-green-700 mt-1">지도에서 원하는 위치를 우클릭하면 좌표가 표시됩니다</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3 p-3 bg-purple-50 rounded-lg">
                      <div className="text-purple-600 text-lg">3️⃣</div>
                      <div className="text-sm">
                        <p className="font-medium text-purple-900">좌표 복사</p>
                        <p className="text-purple-700 mt-1">표시된 좌표를 복사해서 아래 입력란에 붙여넣으세요</p>
                      </div>
                    </div>
                  </div>
                  <div className="p-3 bg-gray-50 rounded-lg">
                    <p className="text-xs text-gray-600 mb-2">💡 팁</p>
                    <p className="text-xs text-gray-700">
                      구글맵에서 "37.5665, 126.9780" 형태로 좌표가 표시됩니다. 
                      쉼표를 포함해서 복사하면 위도와 경도가 자동으로 분리됩니다.
                    </p>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>
          <p className="text-xs text-gray-500 mt-1">
            구글맵에서 주소를 검색한 후, 좌표를 복사해서 아래 입력란에 붙여넣으세요
          </p>
        </div>
        
        {/* 위도/경도 직접 입력 */}
        <div>
          <Label className="mb-2 block">좌표 직접 입력</Label>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label htmlFor="lat-input" className="text-xs text-gray-600 mb-1 block">위도 (Latitude)</Label>
              <Input 
                id="lat-input"
                type="number" 
                step="any"
                value={lat ?? ''} 
                onChange={(e) => {
                  const value = e.target.value === '' ? undefined : Number(e.target.value);
                  onLocationChange(value || 0, lng || 0);
                }} 
                placeholder="37.5665" 
                className="text-sm h-9"
              />
            </div>
            <div>
              <Label htmlFor="lng-input" className="text-xs text-gray-600 mb-1 block">경도 (Longitude)</Label>
              <Input 
                id="lng-input"
                type="number" 
                step="any"
                value={lng ?? ''} 
                onChange={(e) => {
                  const value = e.target.value === '' ? undefined : Number(e.target.value);
                  onLocationChange(lat || 0, value || 0);
                }} 
                placeholder="126.9780" 
                className="text-sm h-9"
              />
            </div>
          </div>
          
          {/* 좌표 붙여넣기 기능 */}
          <div className="mt-3 p-3 bg-gray-50 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <Copy className="h-4 w-4 text-gray-600" />
              <span className="text-sm font-medium text-gray-700">좌표 붙여넣기</span>
            </div>
            <div className="flex gap-2">
              <Input 
                placeholder="37.5665, 126.9780 (구글맵에서 복사한 좌표)" 
                className="text-xs h-8"
                onPaste={(e) => {
                  e.preventDefault();
                  const pastedText = e.clipboardData.getData('text');
                  const coordinates = pastedText.trim().split(',');
                  
                  if (coordinates.length === 2) {
                    const latValue = parseFloat(coordinates[0].trim());
                    const lngValue = parseFloat(coordinates[1].trim());
                    
                    if (!isNaN(latValue) && !isNaN(lngValue)) {
                      onLocationChange(latValue, lngValue);
                      e.currentTarget.value = '';
                    } else {
                      alert('올바른 좌표 형식이 아닙니다. "위도, 경도" 형태로 입력해주세요.');
                    }
                  } else {
                    alert('좌표를 "위도, 경도" 형태로 입력해주세요. (예: 37.5665, 126.9780)');
                  }
                }}
              />
              <Button 
                size="sm" 
                variant="outline" 
                className="text-xs h-8 px-3"
                onClick={() => {
                  const input = document.querySelector('input[placeholder*="구글맵에서 복사한 좌표"]') as HTMLInputElement;
                  if (input) {
                    input.focus();
                    input.select();
                  }
                }}
              >
                붙여넣기
              </Button>
            </div>
            <p className="text-xs text-gray-500 mt-1">
              구글맵에서 복사한 좌표를 위 입력란에 붙여넣으면 자동으로 위도와 경도가 분리됩니다
            </p>
          </div>
          
          <div className="mt-2 flex items-center gap-2 text-xs text-zinc-500">
            <span>💡</span>
            <span>좌표를 직접 입력하거나, 지도를 클릭하여 위치를 설정할 수 있습니다</span>
          </div>
        </div>
      </div>
    </div>
  );
}
