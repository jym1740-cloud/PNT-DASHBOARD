"use client";
import React, { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Edit3, Trash2, MapPin, Loader2, X, RefreshCw } from "lucide-react";
import { Project, ProjectStatus } from "@/lib/types";
import { STATUS_COLORS, STATUS_LABELS } from "@/lib/constants";
import { getStatusInfo, formatKRW, calculateInvestmentRate } from "@/lib/utils";
import MultiManagerInput from "@/components/MultiManagerInput";
import CurrencyKRW from "@/components/CurrencyKRW";

interface ProjectManagementProps {
  projects: Project[];
  onProjectUpdate: (updatedProjects: Project[]) => void;
  onProjectDelete: (projectId: string) => void;
  onProjectAdd: (project: Project) => void;
}

export default function ProjectManagement({
  projects,
  onProjectUpdate,
  onProjectDelete,
  onProjectAdd
}: ProjectManagementProps) {
  const [selected, setSelected] = useState<Project | null>(null);
  const [open, setOpen] = useState(false);
  const [pickOnMap, setPickOnMap] = useState(false);
  const [busy, setBusy] = useState(false);
  const [addressSearch, setAddressSearch] = useState("");
  const [isSearching, setIsSearching] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selected) return;

    setBusy(true);
    try {
      // 주소 검색 및 좌표 변환 로직
      if (addressSearch.trim()) {
        // 여기에 geocoding 로직 구현
        console.log("주소 검색:", addressSearch);
      }

      const updatedProjects = projects.map(p => 
        p.id === selected.id ? selected : p
      );
      onProjectUpdate(updatedProjects);
      setOpen(false);
      setSelected(null);
      setAddressSearch("");
    } catch (error) {
      console.error("프로젝트 업데이트 오류:", error);
    } finally {
      setBusy(false);
    }
  };

  const handleDelete = () => {
    if (selected) {
      onProjectDelete(selected.id);
      setOpen(false);
      setSelected(null);
    }
  };

  const handleAdd = () => {
    const newProject: Project = {
      id: `project_${Date.now()}`,
      name: "새 프로젝트",
      description: "",
      status: "planning" as ProjectStatus,
      startDate: new Date().toISOString().split('T')[0],
      endDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      budget: 0,
      spent: 0,
      location: "",
      coordinates: [37.5665, 126.9780],
      managers: [],
      progress: 0,
      priority: "medium",
      category: "development",
      tags: [],
      notes: "",
      attachments: [],
      lastUpdated: new Date().toISOString()
    };
    setSelected(newProject);
    setOpen(true);
  };

  return (
    <>
      {/* 프로젝트 추가 버튼 */}
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-gray-900">프로젝트 관리</h2>
        <Button onClick={handleAdd} className="flex items-center gap-2">
          <Plus className="w-4 h-4" />
          새 프로젝트
        </Button>
      </div>

      {/* 프로젝트 편집 다이얼로그 */}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {selected?.id.startsWith('project_') ? '새 프로젝트 추가' : '프로젝트 편집'}
            </DialogTitle>
          </DialogHeader>
          
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* 기본 정보 */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="name">프로젝트명 *</Label>
                <Input
                  id="name"
                  value={selected?.name || ""}
                  onChange={(e) => setSelected(prev => prev ? {...prev, name: e.target.value} : null)}
                  required
                />
              </div>
              
              <div>
                <Label htmlFor="status">상태</Label>
                <Select
                  value={selected?.status || "planning"}
                  onValueChange={(value) => setSelected(prev => prev ? {...prev, status: value as ProjectStatus} : null)}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {Object.entries(STATUS_LABELS).map(([key, label]) => (
                      <SelectItem key={key} value={key}>
                        <div className="flex items-center gap-2">
                          <div className={`w-3 h-3 rounded-full ${STATUS_COLORS[key as ProjectStatus]}`} />
                          {label}
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label htmlFor="description">설명</Label>
              <Textarea
                id="description"
                value={selected?.description || ""}
                onChange={(e) => setSelected(prev => prev ? {...prev, description: e.target.value} : null)}
                rows={3}
              />
            </div>

            {/* 날짜 및 예산 */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label htmlFor="startDate">시작일</Label>
                <Input
                  id="startDate"
                  type="date"
                  value={selected?.startDate || ""}
                  onChange={(e) => setSelected(prev => prev ? {...prev, startDate: e.target.value} : null)}
                />
              </div>
              
              <div>
                <Label htmlFor="endDate">종료일</Label>
                <Input
                  id="endDate"
                  type="date"
                  value={selected?.endDate || ""}
                  onChange={(e) => setSelected(prev => prev ? {...prev, endDate: e.target.value} : null)}
                />
              </div>
              
              <div>
                <Label htmlFor="priority">우선순위</Label>
                <Select
                  value={selected?.priority || "medium"}
                  onValueChange={(value) => setSelected(prev => prev ? {...prev, priority: value} : null)}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">낮음</SelectItem>
                    <SelectItem value="medium">보통</SelectItem>
                    <SelectItem value="high">높음</SelectItem>
                    <SelectItem value="urgent">긴급</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* 예산 정보 */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="budget">예산 (KRW)</Label>
                <CurrencyKRW
                  value={selected?.budget || 0}
                  onChange={(value) => setSelected(prev => prev ? {...prev, budget: value} : null)}
                />
              </div>
              
              <div>
                <Label htmlFor="spent">지출 (KRW)</Label>
                <CurrencyKRW
                  value={selected?.spent || 0}
                  onChange={(value) => setSelected(prev => prev ? {...prev, spent: value} : null)}
                />
              </div>
            </div>

            {/* 위치 정보 */}
            <div className="space-y-4">
              <div>
                <Label htmlFor="location">위치</Label>
                <div className="flex gap-2">
                  <Input
                    id="location"
                    value={addressSearch}
                    onChange={(e) => setAddressSearch(e.target.value)}
                    placeholder="주소를 입력하세요"
                  />
                  <Button
                    type="button"
                    onClick={() => setPickOnMap(true)}
                    variant="outline"
                    className="flex items-center gap-2"
                  >
                    <MapPin className="w-4 h-4" />
                    지도에서 선택
                  </Button>
                </div>
              </div>
            </div>

            {/* 매니저 관리 */}
            <div>
              <Label>프로젝트 매니저</Label>
              <MultiManagerInput
                managers={selected?.managers || []}
                onChange={(managers) => setSelected(prev => prev ? {...prev, managers} : null)}
              />
            </div>

            {/* 태그 및 카테고리 */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="category">카테고리</Label>
                <Select
                  value={selected?.category || "development"}
                  onValueChange={(value) => setSelected(prev => prev ? {...prev, category: value} : null)}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="development">개발</SelectItem>
                    <SelectItem value="marketing">마케팅</SelectItem>
                    <SelectItem value="sales">영업</SelectItem>
                    <SelectItem value="operations">운영</SelectItem>
                    <SelectItem value="research">연구</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label htmlFor="tags">태그</Label>
                <Input
                  id="tags"
                  value={selected?.tags?.join(', ') || ""}
                  onChange={(e) => {
                    const tags = e.target.value.split(',').map(tag => tag.trim()).filter(Boolean);
                    setSelected(prev => prev ? {...prev, tags} : null);
                  }}
                  placeholder="태그1, 태그2, 태그3"
                />
              </div>
            </div>

            {/* 메모 */}
            <div>
              <Label htmlFor="notes">메모</Label>
              <Textarea
                id="notes"
                value={selected?.notes || ""}
                onChange={(e) => setSelected(prev => prev ? {...prev, notes: e.target.value} : null)}
                rows={3}
                placeholder="프로젝트 관련 추가 정보..."
              />
            </div>

            {/* 진행률 */}
            <div>
              <Label htmlFor="progress">진행률 (%)</Label>
              <Input
                id="progress"
                type="number"
                min="0"
                max="100"
                value={selected?.progress || 0}
                onChange={(e) => setSelected(prev => prev ? {...prev, progress: parseInt(e.target.value)} : null)}
              />
            </div>
          </form>

          <DialogFooter className="flex gap-2">
            {!selected?.id.startsWith('project_') && (
              <Button
                onClick={handleDelete}
                variant="destructive"
                className="flex items-center gap-2"
              >
                <Trash2 className="w-4 h-4" />
                삭제
              </Button>
            )}
            <Button onClick={() => setOpen(false)} variant="outline">
              취소
            </Button>
            <Button onClick={handleSubmit} disabled={busy} className="flex items-center gap-2">
              {busy && <Loader2 className="w-4 h-4 animate-spin" />}
              {selected?.id.startsWith('project_') ? '추가' : '저장'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
