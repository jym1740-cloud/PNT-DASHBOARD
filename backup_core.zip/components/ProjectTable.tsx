'use client';

import React from 'react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Edit3, Calendar, FileText, Trash2, Globe2 } from 'lucide-react';
import { cn } from '@/lib/utils';

interface Project {
  id: string;
  pjtNo: string;
  name: string;
  status: string;
  pm: string;
  salesManagers?: string[];
  designManagers?: string[];
  controlManagers?: string[];
  productionManagers?: string[];
  budget: number;
  actualCost: number;
  note?: string;
}

interface ProjectTableProps {
  projects: Project[];
  onEdit: (project: Project) => void;
  onSchedule: (project: Project) => void;
  onEquipmentHistory: (project: Project) => void;
  onDelete: (id: string) => void;
}

const STATUS_COLORS: Record<string, string> = {
  "계획": "bg-blue-100 text-blue-700",
  "진행 중": "bg-green-100 text-green-700",
  "진행 중(관리필요)": "bg-red-100 text-red-700",
  "일시 중단": "bg-amber-100 text-amber-700",
  "완료": "bg-zinc-200 text-zinc-700",
};

function StatusBadge({ status }: { status: string }) {
  const statusLabels: Record<string, string> = {
    "Planning": "계획",
    "Active": "진행 중",
    "Active_Management": "진행 중\n(관리필요)",
    "On Hold": "일시 중단",
    "Closed": "완료",
    "계획": "계획",
    "진행 중": "진행 중",
    "진행 중(관리필요)": "진행 중\n(관리필요)",
    "일시 중단": "일시 중단",
    "완료": "완료",
  };
  
  const displayStatus = statusLabels[status] || status;
  const cls = STATUS_COLORS[displayStatus] || "bg-zinc-100 text-zinc-700";
  
  if (displayStatus.includes('\n')) {
    const [line1, line2] = displayStatus.split('\n');
    return (
      <Badge className={cn("rounded-full px-3 py-1 text-xs leading-tight", cls)}>
        <div className="text-center">
          <div>{line1}</div>
          <div className="text-[10px]">{line2}</div>
        </div>
      </Badge>
    );
  }
  
  return <Badge className={cn("rounded-full px-3 py-1 text-xs", cls)}>{displayStatus}</Badge>;
}

function CostRatio({ budget, actualCost }: { budget: number; actualCost: number }) {
  if (budget === 0) return <span className="text-zinc-400">-</span>;
  
  const ratio = (actualCost / budget) * 100;
  const isOverBudget = ratio > 100;
  const isNearBudget = ratio >= 80;
  const isWarning = ratio >= 70;
  
  let colorClass = "text-green-600";
  if (isOverBudget) colorClass = "text-red-600 font-semibold";
  else if (isNearBudget) colorClass = "text-red-600";
  else if (isWarning) colorClass = "text-amber-600";
  
  return (
    <span className={colorClass}>
      {ratio.toFixed(1)}%
    </span>
  );
}

export default function ProjectTable({ 
  projects, 
  onEdit, 
  onSchedule, 
  onEquipmentHistory, 
  onDelete 
}: ProjectTableProps) {
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Globe2 className="h-5 w-5 text-blue-600" />
          <h2 className="font-semibold text-lg">프로젝트 리스트</h2>
        </div>
        <div className="text-xs text-zinc-500">더블클릭: 수정 / 아이콘: 상세 기능</div>
      </div>
      
      <div className="border rounded-lg overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-[120px]">PJT NO</TableHead>
              <TableHead>프로젝트명</TableHead>
              <TableHead className="w-[110px]">상태</TableHead>
              <TableHead className="w-[100px]">PM</TableHead>
              <TableHead className="w-[100px]">영업</TableHead>
              <TableHead className="w-[100px]">설계</TableHead>
              <TableHead className="w-[100px]">제어</TableHead>
              <TableHead className="w-[100px]">제조</TableHead>
              <TableHead className="w-[100px]">투입률</TableHead>
              <TableHead className="w-[150px]">비고</TableHead>
              <TableHead className="w-[90px]"></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {projects.map((p) => (
              <TableRow key={p.id} onDoubleClick={() => onEdit(p)} className="hover:bg-zinc-50">
                <TableCell className="font-mono text-xs">{p.pjtNo}</TableCell>
                <TableCell className="font-medium">{p.name}</TableCell>
                <TableCell><StatusBadge status={p.status} /></TableCell>
                <TableCell className="text-xs">{p.pm}</TableCell>
                <TableCell className="text-xs">{p.salesManagers?.join(", ") || "-"}</TableCell>
                <TableCell className="text-xs">{p.designManagers?.join(", ") || "-"}</TableCell>
                <TableCell className="text-xs">{p.controlManagers?.join(", ") || "-"}</TableCell>
                <TableCell className="text-xs">{p.productionManagers?.join(", ") || "-"}</TableCell>
                <TableCell className="text-center">
                  <CostRatio budget={p.budget} actualCost={p.actualCost || 0} />
                </TableCell>
                <TableCell className="text-xs text-gray-600 max-w-[150px] truncate" title={p.note || ""}>
                  {p.note || "-"}
                </TableCell>
                <TableCell className="text-right">
                  <div className="flex items-center gap-1">
                    <Button 
                      size="icon" 
                      variant="outline" 
                      onClick={() => onEdit(p)}
                      title="프로젝트 수정"
                    >
                      <Edit3 className="h-4 w-4" />
                    </Button>
                    <Button 
                      size="icon" 
                      variant="secondary" 
                      onClick={() => onSchedule(p)}
                      title="일정 관리"
                    >
                      <Calendar className="h-4 w-4" />
                    </Button>
                    <Button 
                      size="icon" 
                      variant="outline" 
                      className="border-purple-200 text-purple-700 hover:bg-purple-50" 
                      onClick={() => onEquipmentHistory(p)}
                      title="설비 이력"
                    >
                      <FileText className="h-4 w-4" />
                    </Button>
                    <Button 
                      size="icon" 
                      variant="ghost" 
                      onClick={() => onDelete(p.id)}
                      title="프로젝트 삭제"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}

