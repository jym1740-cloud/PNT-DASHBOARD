"use client";
import { useEffect, useMemo, useRef, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Globe,
  AlertCircle,
  TrendingUp,
  Clock,
  CheckCircle,
  Calendar,
  MapPin,
  Maximize2,
  ZoomOut,
} from "lucide-react";
// Leaflet 타입 선언
declare global {
  interface Window {
    L: any;
  }
}

// Leaflet 타입 별칭
type LeafletMap = any;
type LeafletLayerGroup = any;

// Project 인터페이스 정의 (WorldMap에서 필요한 속성들)
interface Project {
  id: string;
  pjtNo: string;
  name: string;
  status: string;
  pm: string;
  salesManagers?: string[];
  designManagers?: string[];
  controlManagers?: string[];
  productionManagers?: string[];
  budget: number;
  actualCost: number;
  note?: string;
  lat: number;
  lng: number;
  country?: string;
  city?: string;
}

interface WorldMapProps {
  projects: Project[];
  isLoading?: boolean;
}

/**
 * 개선 포인트
 * - SSR 안전: 동적 import + 스타일 중복 주입 방지(id)
 * - 0도 좌표 허용: truthy 체크 제거, 범위/유효성만 검사
 * - 성능: markersLayer(Group) 재사용, 변화 시 diff 없이 전체 갱신(간단/안전)
 * - 상호작용: Fit to projects / Asia / World / Reset / Wheel-zoom 토글 / 줌 버튼
 * - 클릭 UX: flyTo + popup + 상세 패널 동기화
 * - 접근성/테스트: data-testid, title/aria 라벨 추가
 */

const OSM_TILE = "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png";
const OSM_ATTR = "© OpenStreetMap contributors";
const STYLE_TAG_ID = "leaflet-custom-style";

function getStatusInfo(status: string) {
    switch (status) {
      case "진행 중(관리필요)":
      return { icon: AlertCircle, color: "#ef4444", label: "관리필요" };
      case "진행 중":
      return { icon: TrendingUp, color: "#3b82f6", label: "진행중" };
      case "일시 중단":
      return { icon: Clock, color: "#eab308", label: "일시중단" };
      case "완료":
      return { icon: CheckCircle, color: "#22c55e", label: "완료" };
      default:
      return { icon: Calendar, color: "#9ca3af", label: "계획" };
  }
}

export default function WorldMap({ projects, isLoading = false }: WorldMapProps) {
  console.log("WorldMap 컴포넌트 렌더링 시작", { projects: projects?.length, isLoading });
  
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<LeafletMap | null>(null);
  const markersLayerRef = useRef<LeafletLayerGroup | null>(null);
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [wheelEnabled, setWheelEnabled] = useState(false);
  const [mounted, setMounted] = useState(false);

  // 유효 프로젝트 (0,0 허용 / 범위+유한값만 체크)
  const validProjects = useMemo(
    () => {
      const filtered = projects.filter(
        (p) =>
          Number.isFinite(p.lat) &&
          Number.isFinite(p.lng) &&
          p.lat >= -90 &&
          p.lat <= 90 &&
          p.lng >= -180 &&
          p.lng <= 180
      );
      console.log("WorldMap: 유효한 프로젝트 필터링 결과", { 
        total: projects.length, 
        valid: filtered.length,
        invalid: projects.filter(p => !Number.isFinite(p.lat) || !Number.isFinite(p.lng) || p.lat < -90 || p.lat > 90 || p.lng < -180 || p.lng > 180).map(p => ({ name: p.name, lat: p.lat, lng: p.lng }))
      });
      return filtered;
    },
    [projects]
  );

  // 상태 카운트 (Legend용)
  const statusCounts = useMemo(() => {
    const m = new Map<string, number>();
    for (const p of validProjects) m.set(p.status, (m.get(p.status) || 0) + 1);
    return m;
  }, [validProjects]);

  // 컴포넌트 마운트 확인
  useEffect(() => {
    setMounted(true);
    console.log("WorldMap: 컴포넌트 마운트 완료");
  }, []);

  useEffect(() => {
    console.log("WorldMap: useEffect 실행됨", { window: typeof window, isLoading, mounted });
    
    if (typeof window === "undefined" || isLoading || !mounted) {
      console.log("WorldMap: useEffect 조기 종료", { 
        reason: typeof window === "undefined" ? "SSR" : isLoading ? "로딩 중" : "마운트 안됨" 
      });
      return;
    }

    let isMounted = true;

    const init = async () => {
      console.log("WorldMap: Leaflet 초기화 시작");
      
      const Lmod = await import("leaflet");
      const L = Lmod.default ?? (Lmod as unknown as typeof import("leaflet"));
      console.log("WorldMap: Leaflet 모듈 로드 완료", L);

      // Leaflet 기본 아이콘 이미지 경로 수정 (Webpack에서 자동 처리되지 않는 문제 해결)
      delete (L.Icon.Default as any).prototype._getIconUrl;
      L.Icon.Default.mergeOptions({
        iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon-2x.png',
        iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon.png',
        shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-shadow.png'
      });
      console.log("WorldMap: 아이콘 경로 설정 완료");

      // CSS 한 번만 주입
      if (!document.getElementById(STYLE_TAG_ID)) {
        const style = document.createElement("style");
        style.id = STYLE_TAG_ID;
        style.textContent = `
          .leaflet-container { background: linear-gradient(135deg,#a7c6ed 0%,#89b4e6 100%) !important; }
          .leaflet-control-zoom { background: rgba(255,255,255,.9)!important; border:none!important; border-radius:8px!important; box-shadow:0 4px 6px -1px rgba(0,0,0,.1)!important; }
          .leaflet-control-zoom a { background:transparent!important; border:none!important; color:#374151!important; font-weight:600!important; }
          .leaflet-control-zoom a:hover { background: rgba(59,130,246,.1)!important; color:#1e40af!important; }
          .custom-popup { padding:0!important; }
        `;
        document.head.appendChild(style);
      }

      if (!isMounted || !mapRef.current) {
        console.log("WorldMap: 마운트 상태 또는 mapRef 확인 실패", { isMounted, mapRef: !!mapRef.current });
        return;
      }

      console.log("WorldMap: 지도 컨테이너 엘리먼트 확인", mapRef.current);

      // 기존 맵 제거
      mapInstanceRef.current?.remove();
      console.log("WorldMap: 지도 인스턴스 생성 시작");
      
      const map = L.map(mapRef.current, {
        scrollWheelZoom: wheelEnabled,
        doubleClickZoom: false,
        boxZoom: false,
        keyboard: false,
        zoomControl: false, // 커스텀 버튼 사용
        minZoom: 2,
        maxZoom: 8,
        maxBounds: [
          [-85, -180],
          [85, 180],
        ],
        maxBoundsViscosity: 1.0,
      }).setView([20, 10], 2);

      console.log("WorldMap: 지도 인스턴스 생성 완료", map);

      L.tileLayer(OSM_TILE, {
        attribution: OSM_ATTR,
        minZoom: 2,
        maxZoom: 8,
        noWrap: true,
        bounds: [
          [-85, -180],
          [85, 180],
        ],
      }).addTo(map);

      console.log("WorldMap: 타일 레이어 추가 완료");

      // 마커용 레이어 그룹
      markersLayerRef.current?.remove();
      const markersLayer = L.layerGroup();
      markersLayer.addTo(map);
      markersLayerRef.current = markersLayer;

      mapInstanceRef.current = map;

      console.log("WorldMap: 마커 레이어 그룹 설정 완료");
      console.log("WorldMap: 유효한 프로젝트 수:", validProjects.length);

      // 최초 마커 그리기
      redrawMarkers(L);

      // 최초 fit
      fitToProjects();
    };

    init();

    return () => {
      isMounted = false;
      mapInstanceRef.current?.remove();
      mapInstanceRef.current = null;
      markersLayerRef.current = null;
    };
    // wheelEnabled 포함: 토글 시 map 재생성해 옵션 반영
  }, [isLoading, wheelEnabled]);

  // projects 변경 시 마커만 갱신
  useEffect(() => {
    (async () => {
      if (!mapInstanceRef.current) return;
      const Lmod = await import("leaflet");
      const L = Lmod.default ?? (Lmod as unknown as typeof import("leaflet"));
      redrawMarkers(L);
    })();
  }, [validProjects]);

  function redrawMarkers(L: typeof import("leaflet")) {
    const map = mapInstanceRef.current;
    const markersLayer = markersLayerRef.current;
    if (!map || !markersLayer) {
      console.log("WorldMap: redrawMarkers 실패 - map 또는 markersLayer가 없음", { map: !!map, markersLayer: !!markersLayer });
      return;
    }

    console.log("WorldMap: 마커 다시 그리기 시작, 프로젝트 수:", validProjects.length);
    markersLayer.clearLayers();

    validProjects.forEach((project, index) => {
      console.log(`WorldMap: 프로젝트 ${index + 1} 마커 생성 중:`, { name: project.name, lat: project.lat, lng: project.lng });
      const info = getStatusInfo(project.status);
      const investmentRate = project.budget > 0 ? (
        (project.actualCost / project.budget) * 100
      ).toFixed(1) : "0.0";

      // 커스텀 CircleMarker (캔버스 렌더 → 성능 향상)
      const circle = L.circleMarker([project.lat, project.lng], {
        radius: 7,
        color: info.color,
        weight: 3,
        opacity: 1,
        fillColor: info.color,
        fillOpacity: 0.8,
        pane: "markerPane",
      });

      const popupHtml = `
        <div style="font-family: ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont; max-width: 260px;">
          <div style="font-size: 15px; font-weight: 700; color: #111827; margin-bottom: 6px;">${project.name}</div>
          <div style="font-size: 12px; color: #6b7280; margin-bottom: 6px;">프로젝트 번호: ${project.pjtNo}</div>
          <div style="font-size: 12px; margin-bottom: 6px;"><span style="color:#6b7280">상태:</span> <span style="color:${info.color}; font-weight:600; margin-left:6px">${project.status}</span></div>
          <div style="font-size: 12px; margin-bottom: 6px;"><span style="color:#6b7280">위치:</span> <span style="font-weight:600; margin-left:6px">${project.city || "N/A"}, ${project.country || "N/A"}</span></div>
          <div style="font-size: 12px; margin-bottom: 6px;"><span style="color:#6b7280">투입률:</span> <span style="font-weight:700; margin-left:6px; color:${Number(investmentRate) > 80 ? "#dc2626" : Number(investmentRate) > 70 ? "#d97706" : "#16a34a"}">${investmentRate}%</span></div>
          ${project.note ? `<div style="border-top:1px solid #e5e7eb; padding-top:6px; margin-top:6px; font-size:12px; color:#374151; background:#f9fafb; padding:8px; border-radius:6px;">${project.note}</div>` : ""}
        </div>
      `;

      circle.bindPopup(popupHtml, { maxWidth: 320, className: "custom-popup" });
      circle.on("click", () => {
        setSelectedProject(project);
        map.flyTo([project.lat, project.lng], Math.max(map.getZoom(), 4), { duration: 0.6 });
        circle.openPopup();
      });

      circle.addTo(markersLayer);
    });
  }

  function fitToProjects() {
    const map = mapInstanceRef.current;
    if (!map) return;
    if (validProjects.length === 0) {
      map.setView([20, 10], 2);
      return;
    }
    
    // 동적으로 Leaflet을 import하여 사용
    (async () => {
      const Lmod = await import("leaflet");
      const L = Lmod.default ?? (Lmod as unknown as typeof import("leaflet"));
      const bounds = new L.LatLngBounds(
        validProjects.map((p) => [p.lat, p.lng])
      );
      map.fitBounds(bounds.pad(0.2), { maxZoom: 6 });
    })();
  }

  function asiaView() {
    mapInstanceRef.current?.setView([30, 105], 3); // 대략 아시아 중앙
  }

  function worldView() {
    mapInstanceRef.current?.setView([20, 10], 2);
  }

  function resetView() {
    worldView();
  }

  if (isLoading) {
    return (
      <Card className="bg-gradient-to-br from-slate-50 to-blue-50">
        <CardHeader className="border-b border-slate-200 bg-white rounded-t-xl">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-blue-100 rounded-lg">
              <Globe className="h-6 w-6 text-blue-600" />
            </div>
            <div>
              <CardTitle className="text-xl text-slate-900">글로벌 프로젝트 현황</CardTitle>
              <p className="text-sm text-slate-600">OpenStreetMap 기반 실시간 프로젝트 위치</p>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-6">
          <div className="relative bg-gradient-to-br from-blue-50 to-indigo-100 rounded-2xl p-8 border border-slate-200">
            <div className="w-full h-96 rounded-2xl bg-gradient-to-br from-blue-100 to-indigo-200 animate-pulse flex items-center justify-center">
              <div className="text-center">
                <Globe className="h-16 w-16 text-blue-400 mx-auto mb-4" />
                <p className="text-blue-600 font-medium">지도를 불러오는 중...</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-gradient-to-br from-slate-50 to-blue-50 shadow-lg border-0">
      <CardHeader className="border-b border-slate-200 bg-white rounded-t-xl">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-blue-100 rounded-lg">
                <Globe className="h-6 w-6 text-blue-600" />
              </div>
              <div>
              <CardTitle className="text-xl text-slate-900">글로벌 프로젝트 현황</CardTitle>
              <p className="text-sm text-slate-600">OpenStreetMap 기반 실시간 프로젝트 위치</p>
              </div>
            </div>
          <div className="flex items-center gap-2 flex-wrap">
            <span className="px-3 py-2 text-sm font-medium bg-gray-100 rounded-lg" data-testid="text-total-map-projects">
                총 {validProjects.length}개 프로젝트
            </span>
            <button
              onClick={() => setWheelEnabled((v) => !v)}
              className={`px-3 py-2 text-xs rounded-lg border ${wheelEnabled ? "bg-white" : "bg-white/70"}`}
              title="휠 줌 토글"
            >
              {wheelEnabled ? "휠 줌 ON" : "휠 줌 OFF"}
            </button>
            </div>
          </div>
      </CardHeader>

      <CardContent className="p-6">
        <div className="relative bg-gradient-to-br from-blue-50 to-indigo-100 rounded-2xl overflow-hidden border border-slate-200 shadow-inner">
          {/* Leaflet Map */}
          <div
            ref={mapRef}
            className="w-full h-[500px]"
            style={{ background: "linear-gradient(135deg,#a7c6ed 0%,#89b4e6 100%)" }}
            data-testid="leaflet-map"
            aria-label="세계 지도"
            title="드래그로 이동, 더블클릭 확대 비활성화"
          />

          {/* 컨트롤 버튼들 */}
          <div className="absolute top-4 right-4 flex flex-col gap-2">
            <button
              onClick={fitToProjects}
              className="w-10 h-10 bg-white/90 hover:bg-white rounded-lg shadow-lg flex items-center justify-center transition-transform duration-150 hover:scale-110"
              title="프로젝트 맞춤"
              aria-label="프로젝트 맞춤"
            >
              <Maximize2 className="w-5 h-5 text-gray-700" />
            </button>
            <button
              onClick={asiaView}
              className="w-10 h-10 bg-white/90 hover:bg-white rounded-lg shadow-lg flex items-center justify-center transition-transform duration-150 hover:scale-110"
              title="아시아 보기"
              aria-label="아시아 보기"
            >
              <MapPin className="w-5 h-5 text-gray-700" />
            </button>
            <button
              onClick={worldView}
              className="w-10 h-10 bg-white/90 hover:bg-white rounded-lg shadow-lg flex items-center justify-center transition-transform duration-150 hover:scale-110"
              title="전체 보기"
              aria-label="전체 보기"
            >
              <Globe className="w-5 h-5 text-gray-700" />
            </button>
            <button
              onClick={resetView}
              className="w-10 h-10 bg-white/90 hover:bg-white rounded-lg shadow-lg flex items-center justify-center transition-transform duration-150 hover:scale-110"
              title="기본 보기"
              aria-label="기본 보기"
            >
              <ZoomOut className="w-5 h-5 text-gray-700" />
            </button>
          </div>
          
          {/* Legend */}
          <div className="absolute bottom-4 left-4 right-4">
            <div className="bg-white/90 backdrop-blur-sm rounded-lg p-3 shadow-lg">
              <div className="flex flex-wrap gap-3 justify-center">
            {["진행 중(관리필요)", "진행 중", "일시 중단", "완료", "계획"].map((status) => {
                  const info = getStatusInfo(status);
                  const Icon = info.icon;
                  const count = statusCounts.get(status) || 0;
              return (
                    <div key={status} className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full border-2" style={{ backgroundColor: info.color, borderColor: info.color }} />
                      <Icon className="h-3 w-3" style={{ color: info.color }} />
                      <span className="text-xs text-slate-700 font-medium">{info.label} ({count})</span>
                </div>
              );
            })}
              </div>
            </div>
          </div>
        </div>
        
        {/* Selected project details */}
        {selectedProject && (
          <div className="mt-6 p-6 border-t border-slate-200 bg-white rounded-b-xl">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-slate-900">프로젝트 상세 정보</h3>
              <button
                onClick={() => setSelectedProject(null)}
                className="text-slate-400 hover:text-slate-600 text-2xl leading-none"
                aria-label="상세 닫기"
              >
                ×
              </button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-slate-600 mb-1">프로젝트명</p>
                <p className="font-medium text-slate-900">{selectedProject.name}</p>
              </div>
              <div>
                <p className="text-sm text-slate-600 mb-1">프로젝트 번호</p>
                <p className="font-medium text-slate-900">#{selectedProject.pjtNo}</p>
              </div>
              <div>
                <p className="text-sm text-slate-600 mb-1">상태</p>
                <Badge variant="outline">{selectedProject.status}</Badge>
              </div>
              <div>
                <p className="text-sm text-slate-600 mb-1">위치</p>
                <p className="font-medium text-slate-900">
                  {selectedProject.city || "N/A"}, {selectedProject.country || "N/A"}
                </p>
              </div>
              {selectedProject.budget > 0 && (
                <>
                  <div>
                    <p className="text-sm text-slate-600 mb-1">예산</p>
                    <p className="font-medium text-slate-900">₩{selectedProject.budget.toLocaleString()}</p>
                  </div>
                  <div>
                    <p className="text-sm text-slate-600 mb-1">투입률</p>
                    <p className="font-medium text-slate-900">{((selectedProject.actualCost / selectedProject.budget) * 100).toFixed(1)}%</p>
                  </div>
                </>
              )}
            {selectedProject.note && (
                <div className="md:col-span-2">
                <p className="text-sm text-slate-600 mb-1">비고</p>
                  <p className="text-slate-900 bg-slate-50 p-3 rounded-lg">{selectedProject.note}</p>
              </div>
            )}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
